//Config/config.js
module.exports = {
    port: process.env.PORT || 5000,
    mongodbUri: process.env.MONGODB_URI,
  };
  